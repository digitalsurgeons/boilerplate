# ************************************************************
# Sequel Pro SQL dump
# Version 5438
#
# https://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.5.5-10.3.13-MariaDB)
# Database: craft_boilerplate
# Generation Time: 2019-04-05 16:09:45 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table craft_assetindexdata
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assetindexdata`;

CREATE TABLE `craft_assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` varchar(36) NOT NULL DEFAULT '',
  `volumeId` int(11) NOT NULL,
  `uri` text DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `recordId` int(11) DEFAULT NULL,
  `inProgress` tinyint(1) DEFAULT 0,
  `completed` tinyint(1) DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_assetindexdata_sessionId_volumeId_idx` (`sessionId`,`volumeId`),
  KEY `craft_assetindexdata_volumeId_idx` (`volumeId`),
  CONSTRAINT `craft_assetindexdata_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `craft_volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_assets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assets`;

CREATE TABLE `craft_assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_assets_filename_folderId_idx` (`filename`,`folderId`),
  KEY `craft_assets_folderId_idx` (`folderId`),
  KEY `craft_assets_volumeId_idx` (`volumeId`),
  CONSTRAINT `craft_assets_folderId_fk` FOREIGN KEY (`folderId`) REFERENCES `craft_volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_assets_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_assets_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `craft_volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_assettransformindex
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assettransformindex`;

CREATE TABLE `craft_assettransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT 0,
  `inProgress` tinyint(1) NOT NULL DEFAULT 0,
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_assettransformindex_volumeId_assetId_location_idx` (`volumeId`,`assetId`,`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_assettransforms
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assettransforms`;

CREATE TABLE `craft_assettransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `dimensionChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_assettransforms_name_unq_idx` (`name`),
  UNIQUE KEY `craft_assettransforms_handle_unq_idx` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_categories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_categories`;

CREATE TABLE `craft_categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_categories_groupId_idx` (`groupId`),
  KEY `craft_categories_parentId_fk` (`parentId`),
  CONSTRAINT `craft_categories_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_categories_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_categories_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `craft_categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_categorygroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_categorygroups`;

CREATE TABLE `craft_categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_categorygroups_name_idx` (`name`),
  KEY `craft_categorygroups_handle_idx` (`handle`),
  KEY `craft_categorygroups_structureId_idx` (`structureId`),
  KEY `craft_categorygroups_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `craft_categorygroups_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `craft_categorygroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_categorygroups_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_categorygroups_sites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_categorygroups_sites`;

CREATE TABLE `craft_categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 1,
  `uriFormat` text DEFAULT NULL,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_categorygroups_sites_groupId_siteId_unq_idx` (`groupId`,`siteId`),
  KEY `craft_categorygroups_sites_siteId_idx` (`siteId`),
  CONSTRAINT `craft_categorygroups_sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_categorygroups_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_content
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_content`;

CREATE TABLE `craft_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_content_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `craft_content_siteId_idx` (`siteId`),
  KEY `craft_content_title_idx` (`title`),
  CONSTRAINT `craft_content_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_content_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_content` WRITE;
/*!40000 ALTER TABLE `craft_content` DISABLE KEYS */;

INSERT INTO `craft_content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,1,NULL,'2019-04-05 15:49:19','2019-04-05 15:49:19','00fddc58-95bb-484e-a279-33e07f7e5444'),
	(2,2,1,'Homepage','2019-04-05 16:04:52','2019-04-05 16:04:53','506438c9-b1b7-4acd-83d7-7663c5377670');

/*!40000 ALTER TABLE `craft_content` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_craftidtokens
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_craftidtokens`;

CREATE TABLE `craft_craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_craftidtokens_userId_fk` (`userId`),
  CONSTRAINT `craft_craftidtokens_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_deprecationerrors
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_deprecationerrors`;

CREATE TABLE `craft_deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `traces` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_deprecationerrors_key_fingerprint_unq_idx` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_deprecationerrors` WRITE;
/*!40000 ALTER TABLE `craft_deprecationerrors` DISABLE KEYS */;

INSERT INTO `craft_deprecationerrors` (`id`, `key`, `fingerprint`, `lastOccurrence`, `file`, `line`, `message`, `traces`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'allowAutoUpdates','/Users/coryzibell/sites/boilerplate/config/general.php','2019-04-05 16:02:04','/Users/coryzibell/sites/boilerplate/config/general.php',NULL,'The allowAutoUpdates config setting has been renamed to allowUpdates.','[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/craftcms/cms/src/config/GeneralConfig.php\",\"line\":863,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"allowAutoUpdates\\\", \\\"The allowAutoUpdates config setting has been renamed to allowUpd...\\\", \\\"/Users/coryzibell/sites/boilerplate/config/general.php\\\"\"},{\"objectClass\":\"craft\\\\config\\\\GeneralConfig\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/craftcms/cms/src/services/Config.php\",\"line\":109,\"class\":\"craft\\\\config\\\\GeneralConfig\",\"method\":\"__construct\",\"args\":\"[\\\"defaultWeekStartDay\\\" => 0, \\\"enableCsrfProtection\\\" => true, \\\"omitScriptNameInUrls\\\" => true, \\\"cpTrigger\\\" => \\\"admin\\\", ...]\"},{\"objectClass\":\"craft\\\\services\\\\Config\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/craftcms/cms/src/services/Config.php\",\"line\":175,\"class\":\"craft\\\\services\\\\Config\",\"method\":\"getConfigSettings\",\"args\":\"\\\"general\\\"\"},{\"objectClass\":\"craft\\\\services\\\\Config\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/craftcms/cms/src/helpers/App.php\",\"line\":614,\"class\":\"craft\\\\services\\\\Config\",\"method\":\"getGeneral\",\"args\":null},{\"objectClass\":null,\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/craftcms/cms/src/config/app.web.php\",\"line\":11,\"class\":\"craft\\\\helpers\\\\App\",\"method\":\"webRequestConfig\",\"args\":null},{\"objectClass\":null,\"file\":null,\"line\":null,\"class\":null,\"method\":\"{closure}\",\"args\":null},{\"objectClass\":null,\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/yiisoft/yii2/di/Container.php\",\"line\":508,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"Closure, []\"},{\"objectClass\":\"yii\\\\di\\\\Container\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/yiisoft/yii2/BaseYii.php\",\"line\":351,\"class\":\"yii\\\\di\\\\Container\",\"method\":\"invoke\",\"args\":\"Closure, []\"},{\"objectClass\":null,\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/yiisoft/yii2/di/ServiceLocator.php\",\"line\":137,\"class\":\"yii\\\\BaseYii\",\"method\":\"createObject\",\"args\":\"Closure\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/yiisoft/yii2/base/Module.php\",\"line\":742,\"class\":\"yii\\\\di\\\\ServiceLocator\",\"method\":\"get\",\"args\":\"\\\"request\\\", true\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/craftcms/cms/src/web/Application.php\",\"line\":348,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"get\",\"args\":\"\\\"request\\\", true\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/yiisoft/yii2/web/Application.php\",\"line\":160,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"get\",\"args\":\"\\\"request\\\"\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/craftcms/cms/src/helpers/App.php\",\"line\":487,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"getRequest\",\"args\":null},{\"objectClass\":null,\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/craftcms/cms/src/config/app.php\",\"line\":207,\"class\":\"craft\\\\helpers\\\\App\",\"method\":\"logConfig\",\"args\":null},{\"objectClass\":null,\"file\":null,\"line\":null,\"class\":null,\"method\":\"{closure}\",\"args\":null},{\"objectClass\":null,\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/yiisoft/yii2/di/Container.php\",\"line\":508,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"Closure, []\"},{\"objectClass\":\"yii\\\\di\\\\Container\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/yiisoft/yii2/BaseYii.php\",\"line\":351,\"class\":\"yii\\\\di\\\\Container\",\"method\":\"invoke\",\"args\":\"Closure, []\"},{\"objectClass\":null,\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/yiisoft/yii2/di/ServiceLocator.php\",\"line\":137,\"class\":\"yii\\\\BaseYii\",\"method\":\"createObject\",\"args\":\"Closure\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/yiisoft/yii2/base/Module.php\",\"line\":742,\"class\":\"yii\\\\di\\\\ServiceLocator\",\"method\":\"get\",\"args\":\"\\\"log\\\", true\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/craftcms/cms/src/web/Application.php\",\"line\":348,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"get\",\"args\":\"\\\"log\\\", true\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/yiisoft/yii2/base/Application.php\",\"line\":508,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"get\",\"args\":\"\\\"log\\\"\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/craftcms/cms/src/base/ApplicationTrait.php\",\"line\":1210,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"getLog\",\"args\":null},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/craftcms/cms/src/web/Application.php\",\"line\":109,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"_preInit\",\"args\":null},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/yiisoft/yii2/base/BaseObject.php\",\"line\":109,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"init\",\"args\":null},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/yiisoft/yii2/base/Application.php\",\"line\":206,\"class\":\"yii\\\\base\\\\BaseObject\",\"method\":\"__construct\",\"args\":\"[\\\"env\\\" => \\\"local\\\", \\\"components\\\" => [\\\"config\\\" => craft\\\\services\\\\Config, \\\"api\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\Api\\\"], \\\"assets\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\Assets\\\"], \\\"assetIndexer\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\AssetIndexer\\\"], ...], \\\"id\\\" => \\\"CraftCMS\\\", \\\"name\\\" => \\\"Craft CMS\\\", ...]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/craftcms/cms/src/web/Application.php\",\"line\":100,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"__construct\",\"args\":\"[\\\"env\\\" => \\\"local\\\", \\\"components\\\" => [\\\"config\\\" => craft\\\\services\\\\Config, \\\"api\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\Api\\\"], \\\"assets\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\Assets\\\"], \\\"assetIndexer\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\AssetIndexer\\\"], ...], \\\"id\\\" => \\\"CraftCMS\\\", \\\"name\\\" => \\\"Craft CMS\\\", ...]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":null,\"line\":null,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"__construct\",\"args\":\"[\\\"vendorPath\\\" => \\\"/Users/coryzibell/sites/boilerplate/vendor\\\", \\\"env\\\" => \\\"local\\\", \\\"components\\\" => [\\\"config\\\" => craft\\\\services\\\\Config, \\\"api\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\Api\\\"], \\\"assets\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\Assets\\\"], \\\"assetIndexer\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\AssetIndexer\\\"], ...], \\\"id\\\" => \\\"CraftCMS\\\", ...]\"},{\"objectClass\":\"ReflectionClass\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/yiisoft/yii2/di/Container.php\",\"line\":384,\"class\":\"ReflectionClass\",\"method\":\"newInstanceArgs\",\"args\":\"[[\\\"vendorPath\\\" => \\\"/Users/coryzibell/sites/boilerplate/vendor\\\", \\\"env\\\" => \\\"local\\\", \\\"components\\\" => [\\\"config\\\" => craft\\\\services\\\\Config, \\\"api\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\Api\\\"], \\\"assets\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\Assets\\\"], \\\"assetIndexer\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\AssetIndexer\\\"], ...], \\\"id\\\" => \\\"CraftCMS\\\", ...]]\"},{\"objectClass\":\"yii\\\\di\\\\Container\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/yiisoft/yii2/di/Container.php\",\"line\":156,\"class\":\"yii\\\\di\\\\Container\",\"method\":\"build\",\"args\":\"\\\"craft\\\\web\\\\Application\\\", [], [\\\"vendorPath\\\" => \\\"/Users/coryzibell/sites/boilerplate/vendor\\\", \\\"env\\\" => \\\"local\\\", \\\"components\\\" => [\\\"config\\\" => craft\\\\services\\\\Config, \\\"api\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\Api\\\"], \\\"assets\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\Assets\\\"], \\\"assetIndexer\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\AssetIndexer\\\"], ...], \\\"id\\\" => \\\"CraftCMS\\\", ...]\"},{\"objectClass\":\"yii\\\\di\\\\Container\",\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/yiisoft/yii2/BaseYii.php\",\"line\":349,\"class\":\"yii\\\\di\\\\Container\",\"method\":\"get\",\"args\":\"\\\"craft\\\\web\\\\Application\\\", [], [\\\"vendorPath\\\" => \\\"/Users/coryzibell/sites/boilerplate/vendor\\\", \\\"env\\\" => \\\"local\\\", \\\"components\\\" => [\\\"config\\\" => craft\\\\services\\\\Config, \\\"api\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\Api\\\"], \\\"assets\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\Assets\\\"], \\\"assetIndexer\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\AssetIndexer\\\"], ...], \\\"id\\\" => \\\"CraftCMS\\\", ...]\"},{\"objectClass\":null,\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/craftcms/cms/bootstrap/bootstrap.php\",\"line\":255,\"class\":\"yii\\\\BaseYii\",\"method\":\"createObject\",\"args\":\"[\\\"vendorPath\\\" => \\\"/Users/coryzibell/sites/boilerplate/vendor\\\", \\\"env\\\" => \\\"local\\\", \\\"components\\\" => [\\\"config\\\" => craft\\\\services\\\\Config, \\\"api\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\Api\\\"], \\\"assets\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\Assets\\\"], \\\"assetIndexer\\\" => [\\\"class\\\" => \\\"craft\\\\services\\\\AssetIndexer\\\"], ...], \\\"id\\\" => \\\"CraftCMS\\\", ...]\"},{\"objectClass\":null,\"file\":\"/Users/coryzibell/sites/boilerplate/vendor/craftcms/cms/bootstrap/web.php\",\"line\":42,\"class\":null,\"method\":\"require\",\"args\":\"\\\"/Users/coryzibell/sites/boilerplate/vendor/craftcms/cms/bootstra...\\\"\"},{\"objectClass\":null,\"file\":\"/Users/coryzibell/sites/boilerplate/web/index.php\",\"line\":20,\"class\":null,\"method\":\"require\",\"args\":\"\\\"/Users/coryzibell/sites/boilerplate/vendor/craftcms/cms/bootstra...\\\"\"}]','2019-04-05 16:02:04','2019-04-05 16:02:04','350d99fc-10be-43fa-855e-ce18c3f4116b');

/*!40000 ALTER TABLE `craft_deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_elementindexsettings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_elementindexsettings`;

CREATE TABLE `craft_elementindexsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `settings` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_elementindexsettings_type_unq_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_elements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_elements`;

CREATE TABLE `craft_elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `archived` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_elements_dateDeleted_idx` (`dateDeleted`),
  KEY `craft_elements_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `craft_elements_type_idx` (`type`),
  KEY `craft_elements_enabled_idx` (`enabled`),
  KEY `craft_elements_archived_dateCreated_idx` (`archived`,`dateCreated`),
  CONSTRAINT `craft_elements_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_elements` WRITE;
/*!40000 ALTER TABLE `craft_elements` DISABLE KEYS */;

INSERT INTO `craft_elements` (`id`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`)
VALUES
	(1,NULL,'craft\\elements\\User',1,0,'2019-04-05 15:49:19','2019-04-05 15:49:19',NULL,'f28e3a82-aa9d-4caa-9d57-ede6a96f7426'),
	(2,NULL,'craft\\elements\\Entry',1,0,'2019-04-05 16:04:52','2019-04-05 16:04:53',NULL,'5a2206b4-add1-477d-a2c5-b45798b69948');

/*!40000 ALTER TABLE `craft_elements` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_elements_sites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_elements_sites`;

CREATE TABLE `craft_elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_elements_sites_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `craft_elements_sites_siteId_idx` (`siteId`),
  KEY `craft_elements_sites_slug_siteId_idx` (`slug`,`siteId`),
  KEY `craft_elements_sites_enabled_idx` (`enabled`),
  KEY `craft_elements_sites_uri_siteId_idx` (`uri`,`siteId`),
  CONSTRAINT `craft_elements_sites_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_elements_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_elements_sites` WRITE;
/*!40000 ALTER TABLE `craft_elements_sites` DISABLE KEYS */;

INSERT INTO `craft_elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,1,NULL,NULL,1,'2019-04-05 15:49:19','2019-04-05 15:49:19','903657b5-5f82-4083-a5a9-b6d1c734387e'),
	(2,2,1,'homepage','__home__',1,'2019-04-05 16:04:52','2019-04-05 16:04:53','0233ffc7-fc46-46a6-9bfb-4f9070b8d88b');

/*!40000 ALTER TABLE `craft_elements_sites` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_entries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_entries`;

CREATE TABLE `craft_entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entries_postDate_idx` (`postDate`),
  KEY `craft_entries_expiryDate_idx` (`expiryDate`),
  KEY `craft_entries_authorId_idx` (`authorId`),
  KEY `craft_entries_sectionId_idx` (`sectionId`),
  KEY `craft_entries_typeId_idx` (`typeId`),
  KEY `craft_entries_parentId_fk` (`parentId`),
  CONSTRAINT `craft_entries_authorId_fk` FOREIGN KEY (`authorId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entries_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entries_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `craft_entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_entries_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entries_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `craft_entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_entries` WRITE;
/*!40000 ALTER TABLE `craft_entries` DISABLE KEYS */;

INSERT INTO `craft_entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(2,1,NULL,1,NULL,'2019-04-05 16:04:00',NULL,NULL,'2019-04-05 16:04:52','2019-04-05 16:04:53','3e7f848b-5d5b-4fab-9a46-730cc11baf91');

/*!40000 ALTER TABLE `craft_entries` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_entrydrafts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_entrydrafts`;

CREATE TABLE `craft_entrydrafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `data` mediumtext NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entrydrafts_sectionId_idx` (`sectionId`),
  KEY `craft_entrydrafts_entryId_siteId_idx` (`entryId`,`siteId`),
  KEY `craft_entrydrafts_siteId_idx` (`siteId`),
  KEY `craft_entrydrafts_creatorId_idx` (`creatorId`),
  CONSTRAINT `craft_entrydrafts_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entrydrafts_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `craft_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entrydrafts_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entrydrafts_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_entrytypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_entrytypes`;

CREATE TABLE `craft_entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT 1,
  `titleLabel` varchar(255) DEFAULT 'Title',
  `titleFormat` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entrytypes_name_sectionId_idx` (`name`,`sectionId`),
  KEY `craft_entrytypes_handle_sectionId_idx` (`handle`,`sectionId`),
  KEY `craft_entrytypes_sectionId_idx` (`sectionId`),
  KEY `craft_entrytypes_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `craft_entrytypes_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `craft_entrytypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_entrytypes_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_entrytypes` WRITE;
/*!40000 ALTER TABLE `craft_entrytypes` DISABLE KEYS */;

INSERT INTO `craft_entrytypes` (`id`, `sectionId`, `fieldLayoutId`, `name`, `handle`, `hasTitleField`, `titleLabel`, `titleFormat`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`)
VALUES
	(1,1,NULL,'Homepage','homepage',0,NULL,'{section.name|raw}',1,'2019-04-05 16:04:51','2019-04-05 16:04:51',NULL,'d54160aa-be74-4107-83e7-83664fd9cac6');

/*!40000 ALTER TABLE `craft_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_entryversions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_entryversions`;

CREATE TABLE `craft_entryversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `siteId` int(11) NOT NULL,
  `num` smallint(6) unsigned NOT NULL,
  `notes` text DEFAULT NULL,
  `data` mediumtext NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entryversions_sectionId_idx` (`sectionId`),
  KEY `craft_entryversions_entryId_siteId_idx` (`entryId`,`siteId`),
  KEY `craft_entryversions_siteId_idx` (`siteId`),
  KEY `craft_entryversions_creatorId_idx` (`creatorId`),
  CONSTRAINT `craft_entryversions_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_entryversions_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `craft_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entryversions_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entryversions_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_fieldgroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fieldgroups`;

CREATE TABLE `craft_fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_fieldgroups_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_fieldgroups` WRITE;
/*!40000 ALTER TABLE `craft_fieldgroups` DISABLE KEYS */;

INSERT INTO `craft_fieldgroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'Common','2019-04-05 15:49:19','2019-04-05 15:49:19','47d0fe93-cdf0-4397-aa8b-125b664c141d');

/*!40000 ALTER TABLE `craft_fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_fieldlayoutfields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fieldlayoutfields`;

CREATE TABLE `craft_fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_fieldlayoutfields_layoutId_fieldId_unq_idx` (`layoutId`,`fieldId`),
  KEY `craft_fieldlayoutfields_sortOrder_idx` (`sortOrder`),
  KEY `craft_fieldlayoutfields_tabId_idx` (`tabId`),
  KEY `craft_fieldlayoutfields_fieldId_idx` (`fieldId`),
  CONSTRAINT `craft_fieldlayoutfields_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fieldlayoutfields_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fieldlayoutfields_tabId_fk` FOREIGN KEY (`tabId`) REFERENCES `craft_fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_fieldlayouts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fieldlayouts`;

CREATE TABLE `craft_fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_fieldlayouts_dateDeleted_idx` (`dateDeleted`),
  KEY `craft_fieldlayouts_type_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_fieldlayouttabs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fieldlayouttabs`;

CREATE TABLE `craft_fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_fieldlayouttabs_sortOrder_idx` (`sortOrder`),
  KEY `craft_fieldlayouttabs_layoutId_idx` (`layoutId`),
  CONSTRAINT `craft_fieldlayouttabs_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_fields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fields`;

CREATE TABLE `craft_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `instructions` text DEFAULT NULL,
  `searchable` tinyint(1) NOT NULL DEFAULT 1,
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `settings` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_fields_handle_context_unq_idx` (`handle`,`context`),
  KEY `craft_fields_groupId_idx` (`groupId`),
  KEY `craft_fields_context_idx` (`context`),
  CONSTRAINT `craft_fields_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_globalsets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_globalsets`;

CREATE TABLE `craft_globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_globalsets_name_unq_idx` (`name`),
  UNIQUE KEY `craft_globalsets_handle_unq_idx` (`handle`),
  KEY `craft_globalsets_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `craft_globalsets_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_globalsets_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_info
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_info`;

CREATE TABLE `craft_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT 0,
  `config` mediumtext DEFAULT NULL,
  `configMap` mediumtext DEFAULT NULL,
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_info` WRITE;
/*!40000 ALTER TABLE `craft_info` DISABLE KEYS */;

INSERT INTO `craft_info` (`id`, `version`, `schemaVersion`, `maintenance`, `config`, `configMap`, `fieldVersion`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'3.1.21.1','3.1.26',0,'a:10:{s:11:\"fieldGroups\";a:1:{s:36:\"47d0fe93-cdf0-4397-aa8b-125b664c141d\";a:1:{s:4:\"name\";s:6:\"Common\";}}s:10:\"siteGroups\";a:1:{s:36:\"14016766-27d5-4325-862e-5e29a15ff5fd\";a:1:{s:4:\"name\";s:11:\"Boilerplate\";}}s:5:\"sites\";a:1:{s:36:\"95be2d6d-a690-47b3-9ad2-8175ce774630\";a:8:{s:7:\"baseUrl\";s:17:\"$DEFAULT_SITE_URL\";s:6:\"handle\";s:7:\"default\";s:7:\"hasUrls\";b:1;s:8:\"language\";s:5:\"en-US\";s:4:\"name\";s:11:\"Boilerplate\";s:7:\"primary\";b:1;s:9:\"siteGroup\";s:36:\"14016766-27d5-4325-862e-5e29a15ff5fd\";s:9:\"sortOrder\";i:1;}}s:5:\"email\";a:3:{s:9:\"fromEmail\";s:28:\"techroom@digitalsurgeons.com\";s:8:\"fromName\";s:11:\"Boilerplate\";s:13:\"transportType\";s:37:\"craft\\mail\\transportadapters\\Sendmail\";}s:6:\"system\";a:5:{s:7:\"edition\";s:4:\"solo\";s:4:\"name\";s:11:\"Boilerplate\";s:4:\"live\";b:1;s:13:\"schemaVersion\";s:6:\"3.1.26\";s:8:\"timeZone\";s:19:\"America/Los_Angeles\";}s:5:\"users\";a:5:{s:24:\"requireEmailVerification\";b:1;s:23:\"allowPublicRegistration\";b:0;s:12:\"defaultGroup\";N;s:14:\"photoVolumeUid\";N;s:12:\"photoSubpath\";s:0:\"\";}s:12:\"dateModified\";i:1554480372;s:7:\"plugins\";a:12:{s:11:\"super-table\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:6:\"2.0.10\";}s:3:\"seo\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"3.1.0\";}s:18:\"position-fieldtype\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:15:\"twig-perversion\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:8:\"twig-dig\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:9:\"nanoslugs\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:6:\"dumper\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:16:\"cp-field-inspect\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:7:\"cookies\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:17:\"environment-label\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:10:\"path-tools\";a:3:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";}s:8:\"molecule\";a:4:{s:7:\"edition\";s:8:\"standard\";s:7:\"enabled\";b:1;s:13:\"schemaVersion\";s:5:\"1.0.0\";s:8:\"settings\";a:2:{s:13:\"pathComponent\";s:17:\"@root/components/\";s:8:\"pathIcon\";s:22:\"@root/components/icons\";}}}s:20:\"superTableBlockTypes\";a:0:{}s:8:\"sections\";a:1:{s:36:\"6bab1b0a-c874-48ca-8e3c-c3c4e5b3c527\";a:7:{s:4:\"name\";s:8:\"Homepage\";s:6:\"handle\";s:8:\"homepage\";s:4:\"type\";s:6:\"single\";s:16:\"enableVersioning\";b:1;s:16:\"propagateEntries\";b:1;s:12:\"siteSettings\";a:1:{s:36:\"95be2d6d-a690-47b3-9ad2-8175ce774630\";a:4:{s:16:\"enabledByDefault\";b:1;s:7:\"hasUrls\";b:1;s:9:\"uriFormat\";s:8:\"__home__\";s:8:\"template\";s:5:\"index\";}}s:10:\"entryTypes\";a:1:{s:36:\"d54160aa-be74-4107-83e7-83664fd9cac6\";a:6:{s:4:\"name\";s:8:\"Homepage\";s:6:\"handle\";s:8:\"homepage\";s:13:\"hasTitleField\";b:0;s:10:\"titleLabel\";N;s:11:\"titleFormat\";s:18:\"{section.name|raw}\";s:9:\"sortOrder\";i:1;}}}}}','[]','zc1fq0lykatN','2019-04-05 15:49:19','2019-04-05 16:06:12','30cfb128-0a75-4379-9360-e751199f16e2');

/*!40000 ALTER TABLE `craft_info` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_matrixblocks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_matrixblocks`;

CREATE TABLE `craft_matrixblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `ownerSiteId` int(11) DEFAULT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_matrixblocks_ownerId_idx` (`ownerId`),
  KEY `craft_matrixblocks_fieldId_idx` (`fieldId`),
  KEY `craft_matrixblocks_typeId_idx` (`typeId`),
  KEY `craft_matrixblocks_sortOrder_idx` (`sortOrder`),
  KEY `craft_matrixblocks_ownerSiteId_idx` (`ownerSiteId`),
  CONSTRAINT `craft_matrixblocks_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocks_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocks_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocks_ownerSiteId_fk` FOREIGN KEY (`ownerSiteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_matrixblocks_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `craft_matrixblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_matrixblocktypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_matrixblocktypes`;

CREATE TABLE `craft_matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_matrixblocktypes_name_fieldId_unq_idx` (`name`,`fieldId`),
  UNIQUE KEY `craft_matrixblocktypes_handle_fieldId_unq_idx` (`handle`,`fieldId`),
  KEY `craft_matrixblocktypes_fieldId_idx` (`fieldId`),
  KEY `craft_matrixblocktypes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `craft_matrixblocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_migrations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_migrations`;

CREATE TABLE `craft_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pluginId` int(11) DEFAULT NULL,
  `type` enum('app','plugin','content') NOT NULL DEFAULT 'app',
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_migrations_pluginId_idx` (`pluginId`),
  KEY `craft_migrations_type_pluginId_idx` (`type`,`pluginId`),
  CONSTRAINT `craft_migrations_pluginId_fk` FOREIGN KEY (`pluginId`) REFERENCES `craft_plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_migrations` WRITE;
/*!40000 ALTER TABLE `craft_migrations` DISABLE KEYS */;

INSERT INTO `craft_migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,NULL,'app','Install','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','dc29789b-7d03-46af-bbcc-f82e983f100f'),
	(2,NULL,'app','m150403_183908_migrations_table_changes','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','89883fc4-409c-43e5-b73a-fddd41085326'),
	(3,NULL,'app','m150403_184247_plugins_table_changes','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','6c6d2988-52c0-4fd3-a660-7f50872bb5a8'),
	(4,NULL,'app','m150403_184533_field_version','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','5d07a256-a794-47cc-bdcc-1ce48582e7a7'),
	(5,NULL,'app','m150403_184729_type_columns','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','be103296-f0f8-4ac4-8673-b87b76243419'),
	(6,NULL,'app','m150403_185142_volumes','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','0b33cf8c-6a7b-4b1b-86f8-3ab5add29d0a'),
	(7,NULL,'app','m150428_231346_userpreferences','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','cfa01f7c-ddd6-49af-9dce-0fac52b267d5'),
	(8,NULL,'app','m150519_150900_fieldversion_conversion','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','7b3316db-250a-41ab-ac6a-a07961d4cecf'),
	(9,NULL,'app','m150617_213829_update_email_settings','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','e1c7b42b-724a-4904-b84d-4fa2a44ab0a2'),
	(10,NULL,'app','m150721_124739_templatecachequeries','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','39f28209-42ac-491f-9398-64bf57782133'),
	(11,NULL,'app','m150724_140822_adjust_quality_settings','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','1f949bcf-8c97-460b-bec0-25ccc182319e'),
	(12,NULL,'app','m150815_133521_last_login_attempt_ip','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','6cc2e518-8855-44fe-af63-89e85c06e71d'),
	(13,NULL,'app','m151002_095935_volume_cache_settings','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','5c58461f-2f43-440a-a3d9-525db334902e'),
	(14,NULL,'app','m151005_142750_volume_s3_storage_settings','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','1d51a805-32da-4e66-8c05-0b857bbed227'),
	(15,NULL,'app','m151016_133600_delete_asset_thumbnails','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','d058cf92-a27e-47f7-a2bc-eddac95a99f1'),
	(16,NULL,'app','m151209_000000_move_logo','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','40b4470b-4305-4790-852c-eb5be193734f'),
	(17,NULL,'app','m151211_000000_rename_fileId_to_assetId','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','becc3ec1-05e8-4b86-a4bd-b19ffb6280d5'),
	(18,NULL,'app','m151215_000000_rename_asset_permissions','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','c5a1ad9a-fc96-4235-b43f-100d0c189908'),
	(19,NULL,'app','m160707_000001_rename_richtext_assetsource_setting','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','983d21e1-9525-4e24-9480-98a56477cd98'),
	(20,NULL,'app','m160708_185142_volume_hasUrls_setting','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','6946fb3a-efd8-4e99-bd5b-3c073dc6fb4a'),
	(21,NULL,'app','m160714_000000_increase_max_asset_filesize','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','f511e826-0b87-499c-ac6e-825330727ff5'),
	(22,NULL,'app','m160727_194637_column_cleanup','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','bb1a0473-e300-4e0d-b1f6-6535bc3bcddf'),
	(23,NULL,'app','m160804_110002_userphotos_to_assets','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','f159ad19-1a84-4a5f-a7c1-98bd02dbbec3'),
	(24,NULL,'app','m160807_144858_sites','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','2d1d6525-e03f-4b97-beff-417b312a4954'),
	(25,NULL,'app','m160829_000000_pending_user_content_cleanup','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','d7674ba5-c112-48b5-bc31-d4ab78d5505a'),
	(26,NULL,'app','m160830_000000_asset_index_uri_increase','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','41132e92-d13d-44ac-8fdb-a248f5025b8f'),
	(27,NULL,'app','m160912_230520_require_entry_type_id','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','d2db6e31-2678-43a3-8cf3-3a0ca9e90634'),
	(28,NULL,'app','m160913_134730_require_matrix_block_type_id','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','9c8e83af-fb60-465a-849d-bed1c98a9ba7'),
	(29,NULL,'app','m160920_174553_matrixblocks_owner_site_id_nullable','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','dc4572cd-7094-4000-a87e-a60277211122'),
	(30,NULL,'app','m160920_231045_usergroup_handle_title_unique','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','3d07aff4-d1df-451a-a49b-71da13f9f75c'),
	(31,NULL,'app','m160925_113941_route_uri_parts','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','367d277e-a2ac-43bd-ab4f-65b0d5e5d9c8'),
	(32,NULL,'app','m161006_205918_schemaVersion_not_null','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','0631cfdf-6412-455c-9bac-28981004082e'),
	(33,NULL,'app','m161007_130653_update_email_settings','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','5cc2b1ca-79eb-45e8-9a3f-d17131f89c89'),
	(34,NULL,'app','m161013_175052_newParentId','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','ce258783-a06b-4ae1-80ea-4ef2adcaf6e8'),
	(35,NULL,'app','m161021_102916_fix_recent_entries_widgets','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','e5b7d527-4fdf-4395-be99-a544b3355774'),
	(36,NULL,'app','m161021_182140_rename_get_help_widget','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','b292cac9-ebcb-41ce-93a2-899eca951203'),
	(37,NULL,'app','m161025_000000_fix_char_columns','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','feec4891-1d5c-457a-8810-f1e505d2537d'),
	(38,NULL,'app','m161029_124145_email_message_languages','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','a5709948-1ce2-4e33-8588-6493a3890775'),
	(39,NULL,'app','m161108_000000_new_version_format','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','f36ab024-b794-4b27-b338-02e466f1e015'),
	(40,NULL,'app','m161109_000000_index_shuffle','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','c8cac7eb-d6ad-4dfe-8a3f-967af76b98ff'),
	(41,NULL,'app','m161122_185500_no_craft_app','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','ca75cf0e-7751-456a-8763-112934983cf3'),
	(42,NULL,'app','m161125_150752_clear_urlmanager_cache','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','c6cac894-1085-4c17-bb3c-b4ac73f841fa'),
	(43,NULL,'app','m161220_000000_volumes_hasurl_notnull','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','a5ee780d-075c-4a29-9b01-2a88f55a2c2d'),
	(44,NULL,'app','m170114_161144_udates_permission','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','9a587b2f-3bbe-4dfb-a717-ce88548d8b4c'),
	(45,NULL,'app','m170120_000000_schema_cleanup','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','c8bd1e73-b59e-47f7-8170-35becbff50fe'),
	(46,NULL,'app','m170126_000000_assets_focal_point','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','74d3ff66-7b37-4227-98f1-2fda74ce6c5a'),
	(47,NULL,'app','m170206_142126_system_name','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','cbdb6cb7-bb29-45da-8ccd-24d5493a5132'),
	(48,NULL,'app','m170217_044740_category_branch_limits','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','ba106084-59dc-4cf7-bf68-767692bc5476'),
	(49,NULL,'app','m170217_120224_asset_indexing_columns','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','14d50236-e34c-4d15-8968-80a809be748c'),
	(50,NULL,'app','m170223_224012_plain_text_settings','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','40060f8c-7475-4cca-ae79-a35e55a35fe0'),
	(51,NULL,'app','m170227_120814_focal_point_percentage','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','98826eb5-cdca-4b92-b740-d22e0f34f8b7'),
	(52,NULL,'app','m170228_171113_system_messages','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','22980876-0da2-49b4-aa63-42c24937d631'),
	(53,NULL,'app','m170303_140500_asset_field_source_settings','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','d4057b67-b7cc-4e85-9f79-1e1278ea1787'),
	(54,NULL,'app','m170306_150500_asset_temporary_uploads','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','e3bb7a73-54f3-49a2-bafe-1f895d07ec05'),
	(55,NULL,'app','m170523_190652_element_field_layout_ids','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','59d175d1-10e1-440c-af5d-283120c4f95d'),
	(56,NULL,'app','m170612_000000_route_index_shuffle','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','56e80c27-a4b9-4cbd-9522-ee763ccdf3dd'),
	(57,NULL,'app','m170621_195237_format_plugin_handles','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','d976d6e4-9db1-4db6-a83d-d7b7a6cb93ec'),
	(58,NULL,'app','m170630_161027_deprecation_line_nullable','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','3bdf1f79-1e10-4455-86b0-201b9e00905e'),
	(59,NULL,'app','m170630_161028_deprecation_changes','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','3ec0127b-3b90-4e29-ad66-0254e69f790c'),
	(60,NULL,'app','m170703_181539_plugins_table_tweaks','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','5a988df3-493b-48fe-9483-5e8feabcb488'),
	(61,NULL,'app','m170704_134916_sites_tables','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','cff5fc9b-1128-403a-8884-3f89399f1416'),
	(62,NULL,'app','m170706_183216_rename_sequences','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','b789926f-2bb6-4003-a655-4c994c4bca50'),
	(63,NULL,'app','m170707_094758_delete_compiled_traits','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','7adbb746-141a-402f-a64a-b2664448129e'),
	(64,NULL,'app','m170731_190138_drop_asset_packagist','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','3eb10c78-e0e2-4b29-9eab-02f90322267a'),
	(65,NULL,'app','m170810_201318_create_queue_table','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','0a2c17d2-3016-416e-b24b-eb4a3c6f6d1d'),
	(66,NULL,'app','m170816_133741_delete_compiled_behaviors','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','c9a38462-ab53-4a07-b28d-60ffd2056980'),
	(67,NULL,'app','m170903_192801_longblob_for_queue_jobs','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','3063907d-6d70-4aaf-8dc7-51dd601b1c99'),
	(68,NULL,'app','m170914_204621_asset_cache_shuffle','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','3ed97e94-1f31-47b5-83c6-0c6d3e8de3d3'),
	(69,NULL,'app','m171011_214115_site_groups','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','1a92b572-efd2-4137-9126-a5db5601356c'),
	(70,NULL,'app','m171012_151440_primary_site','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','c91ea78b-0d0c-46d9-9d88-7125875ed089'),
	(71,NULL,'app','m171013_142500_transform_interlace','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','04a33739-da51-4894-82c4-8edb300adc33'),
	(72,NULL,'app','m171016_092553_drop_position_select','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','be9cb048-afd6-4166-af0d-7ca60bb78f59'),
	(73,NULL,'app','m171016_221244_less_strict_translation_method','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','6e62a344-1055-42de-8481-b964520f6f33'),
	(74,NULL,'app','m171107_000000_assign_group_permissions','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','b5cc5899-1589-4837-b59e-f211d4d6753b'),
	(75,NULL,'app','m171117_000001_templatecache_index_tune','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','ed52b17d-c71c-4020-a1ab-4f5b57a5ca4d'),
	(76,NULL,'app','m171126_105927_disabled_plugins','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','3d2a2e1c-bd69-4c16-b481-d44e100ec967'),
	(77,NULL,'app','m171130_214407_craftidtokens_table','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','847a6703-f29f-4eb9-bfc2-e0a532c2e872'),
	(78,NULL,'app','m171202_004225_update_email_settings','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','3329c826-457f-422a-84cf-ecc0956b7212'),
	(79,NULL,'app','m171204_000001_templatecache_index_tune_deux','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','fe3e4756-9694-4a75-895d-eb5b64ac7251'),
	(80,NULL,'app','m171205_130908_remove_craftidtokens_refreshtoken_column','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','8c96f9f2-c644-43be-a6ca-27d47421361f'),
	(81,NULL,'app','m171218_143135_longtext_query_column','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','bdc903d2-ff94-47ea-bbc0-1ebfac38e3e3'),
	(82,NULL,'app','m171231_055546_environment_variables_to_aliases','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','31e593e6-d07b-470e-97a2-4792b8733b2e'),
	(83,NULL,'app','m180113_153740_drop_users_archived_column','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','8b14c90d-ef41-4188-ac3a-0d742d43587d'),
	(84,NULL,'app','m180122_213433_propagate_entries_setting','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','99fda45a-bd0b-4cf2-9133-1f18e12afed6'),
	(85,NULL,'app','m180124_230459_fix_propagate_entries_values','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','beaade71-ba6e-41e3-83dd-16e58feddf9c'),
	(86,NULL,'app','m180128_235202_set_tag_slugs','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','b9235675-a710-46c9-a53c-90401122a852'),
	(87,NULL,'app','m180202_185551_fix_focal_points','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','615785f5-ee4a-4696-8eb2-8de609c208c6'),
	(88,NULL,'app','m180217_172123_tiny_ints','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','cb5e9403-b57c-4267-9e97-3fda6a19a60a'),
	(89,NULL,'app','m180321_233505_small_ints','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','808b56bc-e255-4b21-9823-57d086cb657e'),
	(90,NULL,'app','m180328_115523_new_license_key_statuses','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','3ccf195a-c38c-472e-bcf9-fb7088edc06a'),
	(91,NULL,'app','m180404_182320_edition_changes','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','1f31110d-36bc-48e3-a4fb-e7ff8cc98547'),
	(92,NULL,'app','m180411_102218_fix_db_routes','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','0da473ae-3456-4d2a-9921-1b4869237c79'),
	(93,NULL,'app','m180416_205628_resourcepaths_table','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','98b2a7d8-d338-4cbb-9cf3-375a6d4fea15'),
	(94,NULL,'app','m180418_205713_widget_cleanup','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','198b7465-931f-4564-b994-6299c1e73045'),
	(95,NULL,'app','m180425_203349_searchable_fields','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','dfed7c2e-f3cc-437d-ae0c-9845f4490f05'),
	(96,NULL,'app','m180516_153000_uids_in_field_settings','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','2fef1d2d-d3a7-4825-8e1b-fb4e54c1e49c'),
	(97,NULL,'app','m180517_173000_user_photo_volume_to_uid','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','a6c9792d-cb49-433f-a6ca-38bae91626d9'),
	(98,NULL,'app','m180518_173000_permissions_to_uid','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','f3b351d0-7057-49d6-ac73-12c026081cc5'),
	(99,NULL,'app','m180520_173000_matrix_context_to_uids','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','017899a4-1d26-46b5-a1d8-e5aabccc66fb'),
	(100,NULL,'app','m180521_173000_initial_yml_and_snapshot','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','4316dfcf-855e-4fe5-8a3b-e6e15c55ff0e'),
	(101,NULL,'app','m180731_162030_soft_delete_sites','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','0a7dae35-c05e-4ff6-9a0a-a0653a440ee3'),
	(102,NULL,'app','m180810_214427_soft_delete_field_layouts','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','ad2d4bde-79c0-4669-bc5e-4ffca240fe3f'),
	(103,NULL,'app','m180810_214439_soft_delete_elements','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','7aa2cb83-c11e-4b17-8386-1c5130bef7c9'),
	(104,NULL,'app','m180824_193422_case_sensitivity_fixes','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','858bd87b-dc1f-4fe8-9cb0-17eec0159369'),
	(105,NULL,'app','m180901_151639_fix_matrixcontent_tables','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','d596697f-9cf3-4542-aa29-252ff0bafdb1'),
	(106,NULL,'app','m180904_112109_permission_changes','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','faec5d4e-6d77-4a35-9303-667adae61227'),
	(107,NULL,'app','m180910_142030_soft_delete_sitegroups','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','28fa8165-d1f8-4f10-ab77-bd37d23199bc'),
	(108,NULL,'app','m181011_160000_soft_delete_asset_support','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','02c16058-42c3-4195-a118-7817c8c9c1a1'),
	(109,NULL,'app','m181016_183648_set_default_user_settings','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','24163c29-694e-47c0-a7b0-9233df84fdad'),
	(110,NULL,'app','m181017_225222_system_config_settings','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','47383919-d995-4783-8ea6-f99e32f771d8'),
	(111,NULL,'app','m181018_222343_drop_userpermissions_from_config','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','27530ed4-ee0b-46ca-a9b2-1b17416577e6'),
	(112,NULL,'app','m181029_130000_add_transforms_routes_to_config','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','fd0eab04-eb38-4996-8b02-6b691a2ab5e5'),
	(113,NULL,'app','m181112_203955_sequences_table','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','d6b631a4-62ff-4881-8b58-eb64876e2921'),
	(114,NULL,'app','m181121_001712_cleanup_field_configs','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','90d618ca-3f03-4423-838e-0fcd314b315c'),
	(115,NULL,'app','m181128_193942_fix_project_config','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','d31e6358-42aa-4c2c-9925-56a29ec0d350'),
	(116,NULL,'app','m181130_143040_fix_schema_version','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','49aa061f-8286-4645-86bc-27a195174798'),
	(117,NULL,'app','m181211_143040_fix_entry_type_uids','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','01ac1c81-5826-45db-84bf-512f31f14e5b'),
	(118,NULL,'app','m181213_102500_config_map_aliases','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','89caa3fd-0767-4677-bd2d-f8c88657efe1'),
	(119,NULL,'app','m181217_153000_fix_structure_uids','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','8c06101e-2c7f-4fc1-b461-39b1ecc9c1f7'),
	(120,NULL,'app','m190104_152725_store_licensed_plugin_editions','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','ccb38e98-42d3-4a17-929e-3ac54d2c6259'),
	(121,NULL,'app','m190108_110000_cleanup_project_config','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','212e1f83-b177-4bf3-970e-c865a03fafb7'),
	(122,NULL,'app','m190108_113000_asset_field_setting_change','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','1e018466-6813-4a59-962f-021c0ed1d3f9'),
	(123,NULL,'app','m190109_172845_fix_colspan','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','e1943ede-4367-48c8-b334-b92cf1633732'),
	(124,NULL,'app','m190110_150000_prune_nonexisting_sites','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','fa029e10-b647-4384-9b26-748594511f33'),
	(125,NULL,'app','m190110_214819_soft_delete_volumes','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','c6535cab-4a1a-4e59-a621-8ccbeb0babd8'),
	(126,NULL,'app','m190112_124737_fix_user_settings','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','9c3424f4-c61e-4e08-ab59-afcd094b0345'),
	(127,NULL,'app','m190112_131225_fix_field_layouts','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','81bcbc7f-660a-4a92-a067-d7dd3e6f4541'),
	(128,NULL,'app','m190112_201010_more_soft_deletes','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','443c4121-931c-445f-9476-5fdf1baf69f0'),
	(129,NULL,'app','m190114_143000_more_asset_field_setting_changes','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','87ec4062-7288-485c-86aa-b13b99438e6d'),
	(130,NULL,'app','m190121_120000_rich_text_config_setting','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','52683c59-c623-4bd1-805a-f792cc015ce1'),
	(131,NULL,'app','m190125_191628_fix_email_transport_password','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','054b2146-8b0e-4ba5-87dc-29f2745c30d6'),
	(132,NULL,'app','m190128_181422_cleanup_volume_folders','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','eb7b5649-e1a3-4c56-b1bb-b7b7a57c5225'),
	(133,NULL,'app','m190205_140000_fix_asset_soft_delete_index','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','e903c2ea-d51c-4082-9024-293c9b0e9b0f'),
	(134,NULL,'app','m190208_140000_reset_project_config_mapping','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','b2f38a41-4d54-4c01-a269-085ddf666d32'),
	(135,NULL,'app','m190218_143000_element_index_settings_uid','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','00ba78d4-b994-4025-acc9-7ef1641f43e5'),
	(136,NULL,'app','m190401_223843_drop_old_indexes','2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:20','4379fd57-5b7b-45b6-85b4-94478f3b9e01'),
	(137,1,'plugin','Install','2019-04-05 15:49:56','2019-04-05 15:49:56','2019-04-05 15:49:56','91f53746-d113-42c6-889f-5f048915c1ba'),
	(138,1,'plugin','m180210_000000_migrate_content_tables','2019-04-05 15:49:56','2019-04-05 15:49:56','2019-04-05 15:49:56','4aad2e1a-1c61-4175-bc65-0f057b103178'),
	(139,1,'plugin','m180211_000000_type_columns','2019-04-05 15:49:56','2019-04-05 15:49:56','2019-04-05 15:49:56','410c9463-9625-4eec-8889-ad175f6d42c3'),
	(140,1,'plugin','m180219_000000_sites','2019-04-05 15:49:56','2019-04-05 15:49:56','2019-04-05 15:49:56','c5ea305c-3ac8-426d-be06-48d8c46b1ffc'),
	(141,1,'plugin','m180220_000000_fix_context','2019-04-05 15:49:56','2019-04-05 15:49:56','2019-04-05 15:49:56','438e7958-bfea-41df-8365-92f1cdd09ebd'),
	(142,2,'plugin','Install','2019-04-05 15:49:59','2019-04-05 15:49:59','2019-04-05 15:49:59','5e57a0d9-1355-4f93-9e16-5996b963c0d6'),
	(143,2,'plugin','m180906_152947_add_site_id_to_redirects','2019-04-05 15:56:22','2019-04-05 15:56:22','2019-04-05 15:56:22','2da08f14-589c-4f09-9aa5-b0b7df9b57ba'),
	(144,2,'plugin','m190114_152300_upgrade_to_new_data_format','2019-04-05 15:56:22','2019-04-05 15:56:22','2019-04-05 15:56:22','b9a42ef5-2811-41d6-9fb9-9fea9f8efe60'),
	(145,1,'plugin','m190117_000000_soft_deletes','2019-04-05 15:56:22','2019-04-05 15:56:22','2019-04-05 15:56:22','57f9d9a5-4364-4e19-83ca-e54600b2cd74'),
	(146,1,'plugin','m190117_000001_context_to_uids','2019-04-05 15:56:22','2019-04-05 15:56:22','2019-04-05 15:56:22','1c9550ae-186a-40e1-901d-73a47f536ff0'),
	(147,1,'plugin','m190120_000000_fix_supertablecontent_tables','2019-04-05 15:56:22','2019-04-05 15:56:22','2019-04-05 15:56:22','ad78de2c-0e42-4e41-baf1-c2b7bd1a2acc'),
	(148,1,'plugin','m190131_000000_fix_supertable_missing_fields','2019-04-05 15:56:22','2019-04-05 15:56:22','2019-04-05 15:56:22','63fcacad-a2b0-4c79-a3fd-6c6ca3d5f00e'),
	(149,1,'plugin','m190227_100000_fix_project_config','2019-04-05 15:56:22','2019-04-05 15:56:22','2019-04-05 15:56:22','60c2923d-0aee-4b55-a128-651f2630fd1a');

/*!40000 ALTER TABLE `craft_migrations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_plugins
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_plugins`;

CREATE TABLE `craft_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `licenseKeyStatus` enum('valid','invalid','mismatched','astray','unknown') NOT NULL DEFAULT 'unknown',
  `licensedEdition` varchar(255) DEFAULT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_plugins_handle_unq_idx` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_plugins` WRITE;
/*!40000 ALTER TABLE `craft_plugins` DISABLE KEYS */;

INSERT INTO `craft_plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'super-table','2.1.16','2.0.10','unknown',NULL,'2019-04-05 15:49:56','2019-04-05 15:49:56','2019-04-05 16:04:16','d02b049f-a535-4029-a56d-360eaf8e94ae'),
	(2,'seo','3.5.4','3.1.0','unknown',NULL,'2019-04-05 15:49:59','2019-04-05 15:49:59','2019-04-05 16:04:16','81c14bbe-3d2c-4858-9bc9-9a2ef2ca5da4'),
	(3,'position-fieldtype','1.0.14','1.0.0','unknown',NULL,'2019-04-05 15:50:02','2019-04-05 15:50:02','2019-04-05 16:04:16','d22bb99f-400d-40ad-ac37-c6624280ed54'),
	(4,'twig-perversion','2.0.7','1.0.0','unknown',NULL,'2019-04-05 15:50:05','2019-04-05 15:50:05','2019-04-05 16:04:16','94138b97-fdd4-4ee2-9f0b-d3de2653b4c0'),
	(5,'twig-dig','1.0.0','1.0.0','unknown',NULL,'2019-04-05 15:54:35','2019-04-05 15:54:35','2019-04-05 16:04:16','d7f7ede4-7e32-4b51-810a-d5c352a73c3c'),
	(6,'nanoslugs','1.0.3','1.0.0','unknown',NULL,'2019-04-05 15:55:02','2019-04-05 15:55:02','2019-04-05 16:04:16','38f13aae-22a2-4457-b486-28aa307dbd60'),
	(7,'dumper','1.3.1','1.0.0','unknown',NULL,'2019-04-05 15:59:00','2019-04-05 15:59:00','2019-04-05 16:04:16','e5cf2c5f-ca6e-4ea9-bc78-07be61562c84'),
	(8,'cp-field-inspect','1.0.5','1.0.0','unknown',NULL,'2019-04-05 15:59:04','2019-04-05 15:59:04','2019-04-05 16:04:16','d9aaaf61-c5d2-4478-8b7e-f376a5bc718d'),
	(9,'cookies','1.1.11','1.0.0','unknown',NULL,'2019-04-05 15:59:13','2019-04-05 15:59:13','2019-04-05 16:04:16','2aab0ce2-286f-47bf-a773-8d7f096ade5e'),
	(10,'environment-label','3.1.5','1.0.0','unknown',NULL,'2019-04-05 15:59:16','2019-04-05 15:59:16','2019-04-05 16:04:16','0e120c42-11ac-4f3e-9df8-003718f6d3f5'),
	(11,'path-tools','1.0.7','1.0.0','unknown',NULL,'2019-04-05 15:59:20','2019-04-05 15:59:20','2019-04-05 16:04:16','4d3d7b75-fc08-49ee-8122-6e231e48efd9'),
	(12,'molecule','1.2.0','1.0.0','unknown',NULL,'2019-04-05 16:03:50','2019-04-05 16:03:50','2019-04-05 16:04:16','32bf1206-3457-457c-9ce9-e18b98c66183');

/*!40000 ALTER TABLE `craft_plugins` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_queue
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_queue`;

CREATE TABLE `craft_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job` longblob NOT NULL,
  `description` text DEFAULT NULL,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT 0,
  `priority` int(11) unsigned NOT NULL DEFAULT 1024,
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT 0,
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT 0,
  `dateFailed` datetime DEFAULT NULL,
  `error` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_queue_fail_timeUpdated_timePushed_idx` (`fail`,`timeUpdated`,`timePushed`),
  KEY `craft_queue_fail_timeUpdated_delay_idx` (`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_relations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_relations`;

CREATE TABLE `craft_relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_relations_fieldId_sourceId_sourceSiteId_targetId_unq_idx` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `craft_relations_sourceId_idx` (`sourceId`),
  KEY `craft_relations_targetId_idx` (`targetId`),
  KEY `craft_relations_sourceSiteId_idx` (`sourceSiteId`),
  CONSTRAINT `craft_relations_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_relations_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_relations_sourceSiteId_fk` FOREIGN KEY (`sourceSiteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_relations_targetId_fk` FOREIGN KEY (`targetId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_resourcepaths
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_resourcepaths`;

CREATE TABLE `craft_resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_resourcepaths` WRITE;
/*!40000 ALTER TABLE `craft_resourcepaths` DISABLE KEYS */;

INSERT INTO `craft_resourcepaths` (`hash`, `path`)
VALUES
	('218252e5','@mmikkel/cpfieldinspect/resources'),
	('281366be','@craft/web/assets/updater/dist'),
	('33b9e57','@lib/selectize'),
	('3ea246ec','@app/web/assets/plugins/dist'),
	('4fadb22d','@lib/fileupload'),
	('50e18f11','@lib/jquery-touch-events'),
	('514bb1e','@craft/web/assets/cp/dist'),
	('5745b3d3','@lib/picturefill'),
	('59e09382','@lib/d3'),
	('5fe683d4','@craft/web/assets/utilities/dist'),
	('6394c48e','@app/web/assets/updates/dist'),
	('6a5d8404','@lib/garnishjs'),
	('7b0e25b1','@app/web/assets/fields/dist'),
	('7c690bff','@app/web/assets/dashboard/dist'),
	('7f1b503a','@lib/fabric'),
	('84c9e38c','@lib/jquery-ui'),
	('8cc6726f','@app/web/assets/updater/dist'),
	('92018c91','@app/web/assets/craftsupport/dist'),
	('957dadd','@lib/xregexp'),
	('995ede6','@mmikkel/cpfieldinspect/resources'),
	('9a77523d','@craft/web/assets/plugins/dist'),
	('9c932050','@app/web/assets/updateswidget/dist'),
	('a229623e','@app/web/assets/recententries/dist'),
	('a45c0898','@app/web/assets/pluginstore/dist'),
	('bf6445b3','@app/web/assets/cp/dist'),
	('c11361f5','@craft/web/assets/deprecationerrors/dist'),
	('c67f0e0d','@app/web/assets/feed/dist'),
	('c6f8b63','@craft/web/assets/pluginstore/dist'),
	('c741d05f','@craft/web/assets/updates/dist'),
	('ca607829','@lib/velocity'),
	('d647d7c1','@lib/jquery.payment'),
	('dbef8f54','@bower/jquery/dist'),
	('dd1f0722','@app/web/assets/utilities/dist'),
	('e3c54eac','@lib'),
	('f47f24a1','@lib/element-resize-detector');

/*!40000 ALTER TABLE `craft_resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_searchindex
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_searchindex`;

CREATE TABLE `craft_searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `craft_searchindex_keywords_idx` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `craft_searchindex` WRITE;
/*!40000 ALTER TABLE `craft_searchindex` DISABLE KEYS */;

INSERT INTO `craft_searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`)
VALUES
	(1,'username',0,1,' ds admin '),
	(1,'firstname',0,1,''),
	(1,'lastname',0,1,''),
	(1,'fullname',0,1,''),
	(1,'email',0,1,' techroom digitalsurgeons com '),
	(1,'slug',0,1,''),
	(2,'slug',0,1,' homepage '),
	(2,'title',0,1,' homepage ');

/*!40000 ALTER TABLE `craft_searchindex` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_sections
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sections`;

CREATE TABLE `craft_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT 0,
  `propagateEntries` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_sections_handle_idx` (`handle`),
  KEY `craft_sections_name_idx` (`name`),
  KEY `craft_sections_structureId_idx` (`structureId`),
  KEY `craft_sections_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `craft_sections_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_sections` WRITE;
/*!40000 ALTER TABLE `craft_sections` DISABLE KEYS */;

INSERT INTO `craft_sections` (`id`, `structureId`, `name`, `handle`, `type`, `enableVersioning`, `propagateEntries`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`)
VALUES
	(1,NULL,'Homepage','homepage','single',1,1,'2019-04-05 16:04:51','2019-04-05 16:04:51',NULL,'6bab1b0a-c874-48ca-8e3c-c3c4e5b3c527');

/*!40000 ALTER TABLE `craft_sections` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_sections_sites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sections_sites`;

CREATE TABLE `craft_sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 1,
  `uriFormat` text DEFAULT NULL,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_sections_sites_sectionId_siteId_unq_idx` (`sectionId`,`siteId`),
  KEY `craft_sections_sites_siteId_idx` (`siteId`),
  CONSTRAINT `craft_sections_sites_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_sections_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_sections_sites` WRITE;
/*!40000 ALTER TABLE `craft_sections_sites` DISABLE KEYS */;

INSERT INTO `craft_sections_sites` (`id`, `sectionId`, `siteId`, `hasUrls`, `uriFormat`, `template`, `enabledByDefault`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,1,1,'__home__','index',1,'2019-04-05 16:04:51','2019-04-05 16:04:51','a1af8271-eda7-431f-a07d-5f71ff598b9c');

/*!40000 ALTER TABLE `craft_sections_sites` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_seo_redirects
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_seo_redirects`;

CREATE TABLE `craft_seo_redirects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) NOT NULL,
  `to` varchar(255) NOT NULL,
  `type` enum('301','302') NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `siteId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_seo_sitemap
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_seo_sitemap`;

CREATE TABLE `craft_seo_sitemap` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group` enum('sections','categories','customUrls') NOT NULL,
  `url` varchar(255) NOT NULL,
  `frequency` enum('always','hourly','daily','weekly','monthly','yearly','never') NOT NULL,
  `priority` float NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_sequences
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sequences`;

CREATE TABLE `craft_sequences` (
  `name` varchar(255) NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_sessions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sessions`;

CREATE TABLE `craft_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_sessions_uid_idx` (`uid`),
  KEY `craft_sessions_token_idx` (`token`),
  KEY `craft_sessions_dateUpdated_idx` (`dateUpdated`),
  KEY `craft_sessions_userId_idx` (`userId`),
  CONSTRAINT `craft_sessions_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_sessions` WRITE;
/*!40000 ALTER TABLE `craft_sessions` DISABLE KEYS */;

INSERT INTO `craft_sessions` (`id`, `userId`, `token`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'C0-2ZJmgR3GDlIudGqjq7fDG4rg9CRqXqQtU_ez7jLK05axSOCf4638u_lXJCpnaSWPPYERno5jYPmBcw8f3gDqtZPdouIeWLbA-','2019-04-05 15:49:20','2019-04-05 16:06:18','07fced65-8006-410b-9315-dd2fc49eb037');

/*!40000 ALTER TABLE `craft_sessions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_shunnedmessages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_shunnedmessages`;

CREATE TABLE `craft_shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_shunnedmessages_userId_message_unq_idx` (`userId`,`message`),
  CONSTRAINT `craft_shunnedmessages_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_sitegroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sitegroups`;

CREATE TABLE `craft_sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_sitegroups_name_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_sitegroups` WRITE;
/*!40000 ALTER TABLE `craft_sitegroups` DISABLE KEYS */;

INSERT INTO `craft_sitegroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`)
VALUES
	(1,'Boilerplate','2019-04-05 15:49:19','2019-04-05 15:49:19',NULL,'14016766-27d5-4325-862e-5e29a15ff5fd');

/*!40000 ALTER TABLE `craft_sitegroups` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_sites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sites`;

CREATE TABLE `craft_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 0,
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_sites_dateDeleted_idx` (`dateDeleted`),
  KEY `craft_sites_handle_idx` (`handle`),
  KEY `craft_sites_sortOrder_idx` (`sortOrder`),
  KEY `craft_sites_groupId_fk` (`groupId`),
  CONSTRAINT `craft_sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_sites` WRITE;
/*!40000 ALTER TABLE `craft_sites` DISABLE KEYS */;

INSERT INTO `craft_sites` (`id`, `groupId`, `primary`, `name`, `handle`, `language`, `hasUrls`, `baseUrl`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`)
VALUES
	(1,1,1,'Boilerplate','default','en-US',1,'$DEFAULT_SITE_URL',1,'2019-04-05 15:49:19','2019-04-05 15:49:19',NULL,'95be2d6d-a690-47b3-9ad2-8175ce774630');

/*!40000 ALTER TABLE `craft_sites` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_structureelements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_structureelements`;

CREATE TABLE `craft_structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_structureelements_structureId_elementId_unq_idx` (`structureId`,`elementId`),
  KEY `craft_structureelements_root_idx` (`root`),
  KEY `craft_structureelements_lft_idx` (`lft`),
  KEY `craft_structureelements_rgt_idx` (`rgt`),
  KEY `craft_structureelements_level_idx` (`level`),
  KEY `craft_structureelements_elementId_idx` (`elementId`),
  CONSTRAINT `craft_structureelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_structureelements_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_structures
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_structures`;

CREATE TABLE `craft_structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_structures_dateDeleted_idx` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_supertableblocks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_supertableblocks`;

CREATE TABLE `craft_supertableblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `ownerSiteId` int(11) DEFAULT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_supertableblocks_ownerId_idx` (`ownerId`),
  KEY `craft_supertableblocks_fieldId_idx` (`fieldId`),
  KEY `craft_supertableblocks_typeId_idx` (`typeId`),
  KEY `craft_supertableblocks_ownerSiteId_idx` (`ownerSiteId`),
  CONSTRAINT `craft_supertableblocks_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_supertableblocks_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_supertableblocks_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_supertableblocks_ownerSiteId_fk` FOREIGN KEY (`ownerSiteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_supertableblocks_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `craft_supertableblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_supertableblocktypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_supertableblocktypes`;

CREATE TABLE `craft_supertableblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_supertableblocktypes_fieldId_idx` (`fieldId`),
  KEY `craft_supertableblocktypes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `craft_supertableblocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_supertableblocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_systemmessages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_systemmessages`;

CREATE TABLE `craft_systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_systemmessages_key_language_unq_idx` (`key`,`language`),
  KEY `craft_systemmessages_language_idx` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_taggroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_taggroups`;

CREATE TABLE `craft_taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_taggroups_name_idx` (`name`),
  KEY `craft_taggroups_handle_idx` (`handle`),
  KEY `craft_taggroups_dateDeleted_idx` (`dateDeleted`),
  KEY `craft_taggroups_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_taggroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_tags
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_tags`;

CREATE TABLE `craft_tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_tags_groupId_idx` (`groupId`),
  CONSTRAINT `craft_tags_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_tags_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_templatecacheelements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_templatecacheelements`;

CREATE TABLE `craft_templatecacheelements` (
  `cacheId` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  KEY `craft_templatecacheelements_cacheId_idx` (`cacheId`),
  KEY `craft_templatecacheelements_elementId_idx` (`elementId`),
  CONSTRAINT `craft_templatecacheelements_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `craft_templatecaches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_templatecacheelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_templatecachequeries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_templatecachequeries`;

CREATE TABLE `craft_templatecachequeries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `query` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_templatecachequeries_cacheId_idx` (`cacheId`),
  KEY `craft_templatecachequeries_type_idx` (`type`),
  CONSTRAINT `craft_templatecachequeries_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `craft_templatecaches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_templatecaches
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_templatecaches`;

CREATE TABLE `craft_templatecaches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteId` int(11) NOT NULL,
  `cacheKey` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `body` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_templatecaches_cacheKey_siteId_expiryDate_path_idx` (`cacheKey`,`siteId`,`expiryDate`,`path`),
  KEY `craft_templatecaches_cacheKey_siteId_expiryDate_idx` (`cacheKey`,`siteId`,`expiryDate`),
  KEY `craft_templatecaches_siteId_idx` (`siteId`),
  CONSTRAINT `craft_templatecaches_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `craft_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_tokens
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_tokens`;

CREATE TABLE `craft_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text DEFAULT NULL,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_tokens_token_unq_idx` (`token`),
  KEY `craft_tokens_expiryDate_idx` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_usergroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_usergroups`;

CREATE TABLE `craft_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_usergroups_handle_unq_idx` (`handle`),
  UNIQUE KEY `craft_usergroups_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_usergroups_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_usergroups_users`;

CREATE TABLE `craft_usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_usergroups_users_groupId_userId_unq_idx` (`groupId`,`userId`),
  KEY `craft_usergroups_users_userId_idx` (`userId`),
  CONSTRAINT `craft_usergroups_users_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_usergroups_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_userpermissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_userpermissions`;

CREATE TABLE `craft_userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_userpermissions_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_userpermissions_usergroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_userpermissions_usergroups`;

CREATE TABLE `craft_userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_userpermissions_usergroups_permissionId_groupId_unq_idx` (`permissionId`,`groupId`),
  KEY `craft_userpermissions_usergroups_groupId_idx` (`groupId`),
  CONSTRAINT `craft_userpermissions_usergroups_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_userpermissions_usergroups_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `craft_userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_userpermissions_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_userpermissions_users`;

CREATE TABLE `craft_userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_userpermissions_users_permissionId_userId_unq_idx` (`permissionId`,`userId`),
  KEY `craft_userpermissions_users_userId_idx` (`userId`),
  CONSTRAINT `craft_userpermissions_users_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `craft_userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_userpermissions_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_userpreferences
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_userpreferences`;

CREATE TABLE `craft_userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `craft_userpreferences_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_userpreferences` WRITE;
/*!40000 ALTER TABLE `craft_userpreferences` DISABLE KEYS */;

INSERT INTO `craft_userpreferences` (`userId`, `preferences`)
VALUES
	(1,'{\"language\":\"en-US\"}');

/*!40000 ALTER TABLE `craft_userpreferences` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_users`;

CREATE TABLE `craft_users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT 0,
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  `suspended` tinyint(1) NOT NULL DEFAULT 0,
  `pending` tinyint(1) NOT NULL DEFAULT 0,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT 0,
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT 0,
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_users_uid_idx` (`uid`),
  KEY `craft_users_verificationCode_idx` (`verificationCode`),
  KEY `craft_users_email_idx` (`email`),
  KEY `craft_users_username_idx` (`username`),
  KEY `craft_users_photoId_fk` (`photoId`),
  CONSTRAINT `craft_users_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_users_photoId_fk` FOREIGN KEY (`photoId`) REFERENCES `craft_assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_users` WRITE;
/*!40000 ALTER TABLE `craft_users` DISABLE KEYS */;

INSERT INTO `craft_users` (`id`, `username`, `photoId`, `firstName`, `lastName`, `email`, `password`, `admin`, `locked`, `suspended`, `pending`, `lastLoginDate`, `lastLoginAttemptIp`, `invalidLoginWindowStart`, `invalidLoginCount`, `lastInvalidLoginDate`, `lockoutDate`, `hasDashboard`, `verificationCode`, `verificationCodeIssuedDate`, `unverifiedEmail`, `passwordResetRequired`, `lastPasswordChangeDate`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'ds-admin',NULL,NULL,NULL,'techroom@digitalsurgeons.com','$2y$13$CwZLqFLRPN8mLcN1BTDa.uwBr5OB.5Yjb9q4bKqxj7ibmNHUtbwWS',1,0,0,0,'2019-04-05 15:49:20',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2019-04-05 15:49:20','2019-04-05 15:49:20','2019-04-05 15:49:21','caee49ab-fbfb-47bf-be65-7bfec3cc213b');

/*!40000 ALTER TABLE `craft_users` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_volumefolders
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_volumefolders`;

CREATE TABLE `craft_volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_volumefolders_name_parentId_volumeId_unq_idx` (`name`,`parentId`,`volumeId`),
  KEY `craft_volumefolders_parentId_idx` (`parentId`),
  KEY `craft_volumefolders_volumeId_idx` (`volumeId`),
  CONSTRAINT `craft_volumefolders_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `craft_volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_volumefolders_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `craft_volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_volumes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_volumes`;

CREATE TABLE `craft_volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 1,
  `url` varchar(255) DEFAULT NULL,
  `settings` text DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_volumes_name_idx` (`name`),
  KEY `craft_volumes_handle_idx` (`handle`),
  KEY `craft_volumes_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `craft_volumes_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `craft_volumes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table craft_widgets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_widgets`;

CREATE TABLE `craft_widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` text DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_widgets_userId_idx` (`userId`),
  CONSTRAINT `craft_widgets_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `craft_widgets` WRITE;
/*!40000 ALTER TABLE `craft_widgets` DISABLE KEYS */;

INSERT INTO `craft_widgets` (`id`, `userId`, `type`, `sortOrder`, `colspan`, `settings`, `enabled`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"section\":\"*\",\"siteId\":\"1\",\"limit\":10}',1,'2019-04-05 15:49:21','2019-04-05 15:49:21','438b5989-d391-4597-82c8-230fce851de0'),
	(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2019-04-05 15:49:21','2019-04-05 15:49:21','2200c33b-eda9-499b-a8e9-7ab36e2ea119'),
	(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2019-04-05 15:49:21','2019-04-05 15:49:21','8bce513c-136a-4186-8a24-3b1d085d12af'),
	(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2019-04-05 15:49:21','2019-04-05 15:49:21','b8f3d676-37ca-4056-b873-ac93a7160487');

/*!40000 ALTER TABLE `craft_widgets` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
